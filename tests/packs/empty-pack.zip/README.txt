mcviewer empty pack: no assets/minecraft resources
